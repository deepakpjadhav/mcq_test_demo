<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Questions extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('quizmodel');
	}

	public function quizdisplay()
	{
		$data = array();
		//$qu_res = $this->quizmodel->get_questions();
		/*echo "qu_res = "; 
		echo "<pre>"; print_r($qu_res); die;*/
		$data['questions'] = $this->quizmodel->get_questions();
		//echo "data ="; print_r($data); die;
		$this->load->view('play_quiz', $data);
	}
	
	public function resultdisplay()
	{
		//echo 1; die;
		$outOfCount = $correctAnsCount = $wrongAnsCount = 0;
		$resultArr = array();
		$login_id = $this->session->userdata('login_id');

		/*echo "mcq = <pre>";
		print_r($this->input->post()); die;*/

		$mcq_ans = $this->input->post('mcq');
		$que_id = $this->input->post('ques_id');
		if(!empty($que_id) && !empty($mcq_ans)) {
			foreach ($mcq_ans as $key => $selectedAns) {
				$isCorrect = 0;
				$where = array('questions_id' => $que_id[$key]);
				$res_ans = $this->quizmodel->get_questions_db($where); //Get correct answer of question_id
				if(!empty($res_ans)) {
					$correct_ans = $res_ans[0]['answer'];
					if($selectedAns == $correct_ans) { //Check answer
						$correctAnsCount++;
						$isCorrect = 1;
					} else {
						$wrongAnsCount++;
						$isCorrect = 0;
					}
				} else {
					echo "Something went wrong1!"; exit();
				}
				$outOfCount++;
				$result_detailArr[] = array('result_id_fk' => '',
									'questions_id_fk' => $que_id[$key],
									'selected_answer' => $selectedAns,
									'correct_answer' => $isCorrect
								);	
			}
			
			//Insert data in result table
			$resultArr = array('login_id' => $login_id,
								'total_marks' => $correctAnsCount,
								'outof' => $outOfCount,
								'correct_answers' => $correctAnsCount,
								'wrong_answers' => $wrongAnsCount
						);

			$result_id = $this->quizmodel->insert_result($resultArr);

			if($result_id) {
				foreach ($result_detailArr as $key => $value) {
					$result_detailArr[$key]['result_id_fk'] = $result_id;
				}

				$res_ins = $this->quizmodel->insert_result_detail($result_detailArr);
			}

			$data['outOfCount'] = $outOfCount;
			$data['correctAnsCount'] = $correctAnsCount;
			$data['wrongAnsCount'] = $wrongAnsCount; 
		} else {
			echo "Something went wrong2!"; exit();
		}

		$this->load->view('result_display', $data);
	}
}

