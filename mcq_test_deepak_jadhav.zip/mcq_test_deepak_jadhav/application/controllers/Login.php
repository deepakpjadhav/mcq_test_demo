<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('login_model');
	}

	public function index()
	{
		$data = array();
		$this->load->view('login_view', $data);
	}

	public function login_submit() {
		$user_name = $this->input->post('user_name');
		$password = $this->input->post('pwd');

		$login_res = $this->login_model->get_login_details($user_name, sha1($password));
		//echo "login_res = "; print_r($login_res); die;
		if(!empty($login_res)) {
			$session_data = array(
                    'login_id' => $login_res[0]['login_id'],
                    'name' => $login_res[0]['name'],
                    'user_type' => $login_res[0]['user_type'],
                    'validated' => true
                    );
            $this->session->set_userdata($session_data);
		} else {
			$this->session->set_flashdata('error', 'Invalid User Name or Password!');
			redirect('login/index');
		}


		$this->load->view('quiz_game');
	}	
	
	public function resultdisplay()
	{
		//echo 1; die;
		$outOfCount = $correctAnsCount = $wrongAnsCount = 0;
		$resultArr = array();
		$login_id = 1;

		//echo "mcq = <pre>";
		//print_r($this->input->post()); //die;

		$mcq_ans = $this->input->post('mcq');
		$que_id = $this->input->post('ques_id');
		if(!empty($que_id) && !empty($mcq_ans)) {
			foreach ($mcq_ans as $key => $selectedAns) {
				$isCorrect = 0;
				$where = array('questions_id' => $que_id[$key]);
				$res_ans = $this->quizmodel->get_questions_db($where); //Get correct answer of question_id
				if(!empty($res_ans)) {
					$correct_ans = $res_ans[0]['answer'];
					if($selectedAns == $correct_ans) { //Check answer
						$correctAnsCount++;
						$isCorrect = 1;
					} else {
						$wrongAnsCount++;
						$isCorrect = 0;
					}
				} else {
					echo "Something went wrong1!"; exit();
				}
				$outOfCount++;
				$resultArr[] = array('login_id' => $login_id,
									'questions_id_fk' => $que_id[$key],
									'selected_answer' => $selectedAns,
									'correct_answer' => $isCorrect
								);	
			}

			//Insert data in result table
			if(!empty($resultArr)) {
				$res_ins = $this->quizmodel->insert_result($resultArr);
			}

			$data['outOfCount'] = $outOfCount;
			$data['correctAnsCount'] = $correctAnsCount;
			$data['wrongAnsCount'] = $wrongAnsCount; 
		} else {
			echo "Something went wrong2!"; exit();
		}

		$this->load->view('result_display', $data);
	}

	public function test_exit() {
		$this->session->unset_userdata();
		redirect('login/index');
	}
}

