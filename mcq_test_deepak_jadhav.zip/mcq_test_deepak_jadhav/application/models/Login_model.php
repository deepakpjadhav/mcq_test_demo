<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model {

	private $login_tbl = 'login';

	public function get_login_details($userName, $pwd)
	{
		$this->db->select('login_id, name, user_type');
		$this->db->from($this->login_tbl);
		$this->db->where('user_name', $userName);
		$this->db->where('password', $pwd);
		$this->db->where('status', 'active');		
		$result = $this->db->get()->result_array();
		return $result;

	}

	public function get_questions() {
		//Temp data
		$res_db = $this->get_questions_db();
		if(!empty($res_db)) {
			return $res_db;	
		} else {
			echo "Error while getting questions from db!"; exit();
		}

		//End Temp data


		$qu_res = $this->get_questions_from_api();
		/*echo "qu_res = "; 
		echo "<pre>"; print_r($qu_res); die;*/
		$que_arr = array(); //Create array to store data in table
		$options = '';
		if(!empty($qu_res)) {
			foreach ($qu_res['results'] as $key => $value) {
				$que_arr[$key]['category'] = $value['category'];
				$que_arr[$key]['type'] = $value['type'];
				$que_arr[$key]['difficulty'] = $value['difficulty'];
				$que_arr[$key]['question'] = $value['question'];
				$options = $value['correct_answer'].'|';
				foreach ($value['incorrect_answers'] as $key2 => $value2) {
					$options .= $value2.'|';
				}
				$que_arr[$key]['options'] = rtrim($options, "|");
				$que_arr[$key]['answer'] = $value['correct_answer'];
			}
		} else {
			echo "Error while getting questions!"; exit();
		}
		//echo "que_arr = "; print_r($que_arr); //die;
		//Store data in table
		if(!empty($que_arr)) {
			$ins_res = $this->insert_questions($que_arr);
			if($ins_res) {
				$res_db = $this->get_questions_db();
				if(!empty($res_db)) {
					return $res_db;	
				} else {
					echo "Error while getting questions from db!"; exit();
				}
				
			} else {
				echo "Error while storing questions!"; exit();
			}
		}

	}

	//Get data from API
	public function get_questions_from_api() {
		$curl = curl_init();
		$url = $this->config->item('get_questions_url');

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_HTTPHEADER => array(
		    "cache-control: no-cache",
		    "content-type: application/json"
		  )
		));

		$response = curl_exec($curl);
		//echo "response =<pre>"; print_r($response); die;
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  return json_decode($response,true);
		}
	}

	//Store the data in questions table
	public function insert_questions($insertData) {
		$this->db->insert_batch($this->questions_tbl,$insertData);
		return $this->db->insert_id();
	}

	//Get questions from table
	public function get_questions_db($where = array()) {
		$this->db->select('questions_id, question, options, answer');
		$this->db->from('questions');
		if(!empty($where)) {
			$this->db->where($where);
		}
		$this->db->order_by('questions_id','DESC');
		$this->db->limit(2);
		$result = $this->db->get()->result_array();
		return $result;
	}

	//Store the data in result table
	//Store the data in questions table
	public function insert_result($insertData) {
		$this->db->insert_batch($this->result_tbl,$insertData);
		return $this->db->insert_id();
	}

}

