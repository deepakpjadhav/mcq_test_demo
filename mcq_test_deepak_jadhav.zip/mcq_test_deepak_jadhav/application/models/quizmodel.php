<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class quizmodel extends CI_Model {

	private $questions_tbl = 'questions';
	private $result_tbl = 'result';
	private $result_detail_tbl = 'result_detail';

	public function get_questions() {
		$qu_res = $this->get_questions_from_api();
		$que_arr = array(); //Create array to store data in table
		$options = '';
		if(!empty($qu_res)) {
			foreach ($qu_res['results'] as $key => $value) {
				$que_arr[$key]['category'] = $value['category'];
				$que_arr[$key]['type'] = $value['type'];
				$que_arr[$key]['difficulty'] = $value['difficulty'];
				$que_arr[$key]['question'] = $value['question'];
				$options = $value['correct_answer'].'|';
				foreach ($value['incorrect_answers'] as $key2 => $value2) {
					$options .= $value2.'|';
				}
				$que_arr[$key]['options'] = rtrim($options, "|");
				$que_arr[$key]['answer'] = $value['correct_answer'];
			}
		} else {
			echo "Error while getting questions!"; exit();
		}

		//Store data in table
		if(!empty($que_arr)) {
			$ins_res = $this->insert_questions($que_arr);
			if($ins_res) {
				$res_db = $this->get_questions_db();
				if(!empty($res_db)) {
					return $res_db;	
				} else {
					echo "Error while getting questions from db!"; exit();
				}
				
			} else {
				echo "Error while storing questions!"; exit();
			}
		}

	}

	//Get data from API
	public function get_questions_from_api() {
		$curl = curl_init();
		$url = $this->config->item('get_questions_url');

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_HTTPHEADER => array(
		    "cache-control: no-cache",
		    "content-type: application/json"
		  )
		));

		$response = curl_exec($curl);
		//echo "response =<pre>"; print_r($response); die;
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  return json_decode($response,true);
		}
	}

	//Store the data in questions table
	public function insert_questions($insertData) {
		$this->db->insert_batch($this->questions_tbl,$insertData);
		return $this->db->insert_id();
	}

	//Get questions from table
	public function get_questions_db($where = array()) {
		$this->db->select('questions_id, question, options, answer');
		$this->db->from('questions');
		if(!empty($where)) {
			$this->db->where($where);
		}
		$this->db->order_by('questions_id','DESC');
		$this->db->limit(10);
		$result = $this->db->get()->result_array();
		return $result;
	}

	//Store the data in result table
	public function insert_result($insertData) {
		$this->db->insert($this->result_tbl,$insertData);
		return $this->db->insert_id();
	}


	public function insert_result_detail($insertData) {
		$this->db->insert_batch($this->result_detail_tbl,$insertData);
		return $this->db->insert_id();
	}

	//Get result data from table
	public function get_result_data() {
		$this->db->select("login.user_name, login.name, login.user_type, result.total_marks, result.outof, result.correct_answers, result.wrong_answers, DATE_FORMAT(result.record_date, '%d-%m-%Y %H:%i:%s') as record_date", false);
		$this->db->from('result');
		$this->db->join('login','login.login_id = result.login_id','inner');
		$this->db->order_by('result_id','DESC');
		return $this->db->get()->result_array();
	}

}

