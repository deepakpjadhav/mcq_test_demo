<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>MCQ Test Result</title>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
    <meta name="description" content="Use this HTML basic website layout template with the navigation menu on the left, the main content at the center, the extra stuff on the right.">
    <link rel="canonical" href="https://www.w3docs.com/snippets/html/layout_templates/01.html" />
    <style type="text/css">
        html, body {
            margin: 0;
            padding: 0;
        }

        body {
            color: #292929;
            font: 90% Roboto, Arial, sans-serif;
            font-weight: 300;
        }

        p {
            padding: 0 10px;
            line-height: 1.8;
        }

        h3 {
            padding: 5px 20px;
            margin: 0;
        }

        div#header {
            position: relative;
        }

        div#header h1 {
            height: 80px;
            line-height: 80px;
            margin: 0;
            padding-left: 10px;
            background: #e0e0e0;
            color: #292929;
        }

        div#footer {
            background: #42444e;
            color: #fff;
        }

        div#footer p {
            padding: 5px 10px;
        }

        div#wrapper {
            float: left;
            width: 100%;
        }

        div#content {
            margin: 0 25%;
        }

        div#footer {
            clear: left;
            width: 100%;
        }

        .button {
          background-color: red; /* Green */
          border: none;
          color: white;
          padding: 15px 32px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
        }
    </style>
</head>
<body>
<div id="container">
    <div id="header">
        <h1>MCQ Test Result</h1>
    </div><br/><br/>
    <div id="wrapper">
        <div id="content">
          <form method="post" action="<?php echo base_url();?>login/test_exit">
            <center>
            <table border="2">
              <tr bgcolor="sky blue">
                <th><h2>Score</h2></th>
                <th><h2>Percentage</h2></th>
                <th><h2>Correct Answer(s)</h2></th>
                <th><h2>Wrong Answer(s)</h2></th>
              </tr>
              <tr bgcolor="orange">
                <td><h3><?php echo $correctAnsCount; ?> out of <?php echo $outOfCount; ?></h3></td>
                <td><h3><?php echo ($correctAnsCount/$outOfCount)*100; ?>%</h3></td>
                <td><h3><?php echo $correctAnsCount; ?></h3></td>
                <td><h3><?php echo $wrongAnsCount; ?></h3></td>
              </tr>
            </table>
            <br/><br/><br/><br/><br/>
            <input type="submit" name="submit_btn" id="submit_btn" value="Exit!" class="button"><br/><br/>
            </center>
          </form>
        </div>
    </div>
    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    <div id="footer"><p><center>info@mcq_test.com</center></p>
    </div>
</div>
</body>
</html>
