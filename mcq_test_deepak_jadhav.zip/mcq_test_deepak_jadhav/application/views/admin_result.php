<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta charset="utf-8">
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.4/css/jquery.dataTables.min.css">
    <title>Result Dashboard</title>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
    <meta name="description" content="Use this HTML basic website layout template with the navigation menu on the left, the main content at the center, the extra stuff on the right.">
    <link rel="canonical" href="https://www.w3docs.com/snippets/html/layout_templates/01.html" />
    <style type="text/css">
        html, body {
            margin: 0;
            padding: 0;
        }

        body {
            color: #292929;
            font: 90% Roboto, Arial, sans-serif;
            font-weight: 300;
        }

        p {
            padding: 0 10px;
            line-height: 1.8;
        }

        h3 {
            padding: 5px 20px;
            margin: 0;
        }

        div#header {
            position: relative;
        }

        div#header h1 {
            height: 80px;
            line-height: 80px;
            margin: 0;
            padding-left: 10px;
            background: #e0e0e0;
            color: #292929;
        }

        div#footer {
            background: #42444e;
            color: #fff;
        }

        div#footer p {
            padding: 5px 10px;
        }

        div#wrapper {
            float: left;
            width: 100%;
        }

        div#content {
            margin: 0 25%;
        }

        div#footer {
            clear: left;
            width: 100%;
        }

        .button {
          background-color: red; /* Green */
          border: none;
          color: white;
          padding: 15px 32px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
        }
    </style>
</head>
<body>
<div id="container">
    <div id="header">
        <h1>Result Dashboard</h1>
    </div><br/><br/>
    <div id="wrapper">
        <div id="content">
            <form method="post" action="<?php echo base_url();?>login/test_exit">
            <table id="result_tbl" border="1">
                <thead style="background-color: orange;">
                    <th>Sr No</th>
                    <th>User Name</th>
                    <th>Full Name</th>
                    <th>User Type</th>
                    <th>Marks</th>
                    <th>Outof</th>
                    <th>Correct Answers</th>
                    <th>Wrong Answers</th>
                    <th>Test Date</th>
                </thead>
                <tbody>
                    <?php $i = 1;
                        foreach ($result_data as $key => $value) { ?>
                        <tr>
                            <td><?php echo $i; ?> </td>
                            <td><?php echo $value['user_name']; ?> </td>
                            <td><?php echo ucwords($value['name']); ?> </td>
                            <td><?php echo ucwords($value['user_type']); ?> </td>
                            <td><?php echo $value['total_marks']; ?> </td>
                            <td><?php echo $value['outof']; ?> </td>
                            <td><?php echo $value['correct_answers']; ?> </td>
                            <td><?php echo $value['wrong_answers']; ?> </td>
                            <td><?php echo $value['record_date']; ?> </td>
                        </tr>
                    <?php $i++; } ?>
                </tbody>
            </table><br/><br/>
            <center><input type="submit" name="submit_btn" id="submit_btn" value="Exit!" class="button"><br/><br/></center>
        </form>
        </div>
    </div>
    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    <div id="footer"><p><center>info@mcq_test.com</center></p>
    </div>
</div>
</body>
</html>

<script type="text/javascript">
    $(document).ready(function() {
        $("#result_tbl").dataTable();
    });
</script>