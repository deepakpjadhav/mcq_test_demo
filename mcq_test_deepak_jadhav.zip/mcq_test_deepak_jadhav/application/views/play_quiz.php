<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>MCQ Test</title>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
    <meta name="description" content="Use this HTML basic website layout template with the navigation menu on the left, the main content at the center, the extra stuff on the right.">
    <link rel="canonical" href="https://www.w3docs.com/snippets/html/layout_templates/01.html" />
    <style type="text/css">
        html, body {
            margin: 0;
            padding: 0;
        }

        body {
            color: #292929;
            font: 90% Roboto, Arial, sans-serif;
            font-weight: 300;
        }

        p {
            padding: 0 10px;
            line-height: 1.8;
        }

        h3 {
            padding: 5px 20px;
            margin: 0;
        }

        div#header {
            position: relative;
        }

        div#header h1 {
            height: 80px;
            line-height: 80px;
            margin: 0;
            padding-left: 10px;
            background: #e0e0e0;
            color: #292929;
        }

        div#footer {
            background: #42444e;
            color: #fff;
        }

        div#footer p {
            padding: 5px 10px;
        }

        div#wrapper {
            float: left;
            width: 100%;
        }

        div#content {
            margin: 0 25%;
        }

        div#footer {
            clear: left;
            width: 100%;
        }

        .button {
          background-color: #4CAF50; /* Green */
          border: none;
          color: white;
          padding: 15px 32px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
        }
    </style>
</head>
<body>
<div id="container">
    <div id="header">
        <h1>MCQ Test</h1>
    </div><br/><br/>
    <div id="wrapper">
        <div id="content">
            <form method="post" action="<?php echo base_url();?>questions/resultdisplay">
            <?php $i = 1; $x = 101; ?>
            <table style="border-collapse: separate; border-spacing: 0 1em;">
                <?php foreach ($questions as $value) { 
                    $optionsArr = explode("|",$value['options']); //Create array of options
                    shuffle($optionsArr); //Shuffle options sequence every time
                    $char_i = 'A';
                ?>
                        <tr style="text-align: left;">
                            <th><?php echo $i.') '.$value['question'];?></th>
                            <?php foreach ($optionsArr as $value2) { ?>
                                <tr><td><input type="radio" name="mcq[<?php echo $i; ?>]" id="mcqId[<?php echo $x; ?>]" value="<?php echo $value2; ?>"/>
                                <label for="mcqId[<?php echo $x; ?>]"><?php echo $char_i.') '. $value2; ?></label></td></tr>
                            <?php $char_i++; $x++; } ?>
                            <input type="hidden" name="ques_id[<?php echo $i; ?>]" name="ques_id[<?php echo $i; ?>]" value="<?php echo $value['questions_id']; ?>">
                        </tr>
                    
                <?php $i++; } ?>
            </table>

            <br><br>
            <input type="submit" name="submit_btn" id="submit_btn" value="Submit!" class="button"><br/><br/>
            
            </form>
        </div>
    </div>
    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    <div id="footer"><p><center>info@mcq_test.com</center></p>
    </div>
</div>
<script type="text/javascript">AddFillerLink("content")</script>
</body>
</html>

<script type="text/javascript">
    //Required validation for questions
    $("#submit_btn").on( 'click', function (e) {
        //Make groups
        var names = []
        var temp = 1;
        $('input:radio').each(function () {
            var rname = $(this).attr('name');
            if ($.inArray(rname, names) === -1) names.push(rname);
        });
        //do validation for each group
        $.each(names, function (i, name) {
            if ($('input[name="' + name + '"]:checked').length === 0) {
                //mactch() to get number form string
                alert('Please select the answer for Question Number - ' + name.match(/\d+/)); 
                temp++;
            }
        });
        if(temp > 1) {
            e.preventDefault();
        }
    });
    
</script>