<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
for is active checkbox
*/
$config['get_questions_url'] = 'https://opentdb.com/api.php?amount=10'; 

